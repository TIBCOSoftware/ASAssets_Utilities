README:

Simple Install:
----------------
1. Create ASAssets published database
     Right-click on /services/databases and create New --> "New Composite Database Service" --> ASAssets
2. Import Utilities_YYYYQnnn.car to Desktop (admin) with overwrite checked
3. Optional: Import getAssetVersions.car to Desktop (admin)

Simple Upgrade:
----------------
1. Import Utilities_YYYYQnnn.car to Desktop (admin) with overwrite checked
2. Optional: Import getAssetVersions.car to Desktop (admin)