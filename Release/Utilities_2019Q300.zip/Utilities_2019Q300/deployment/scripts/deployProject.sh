#!/bin/bash
#****************************************************************
# BEGIN:  deployProject.sh
#
# Usage: deployProject.sh [-v] [-c] <CAR_file> <options_file> <hostname> <username> <domain> [password] [encryptionPassword]
#
# Any options [-v, -c] must occur before the package file or this procedure will not work.
#  -v=[optional] verbose mode.  Verbose is turned on for secondary script calls.   Otherwise the default is verbose is off.
#  -c=[optional] execute package .car file version check and conversion.  
#                Use -c in environments where you are migrating from DV 8.x into DV 7.x.
#                If not provided, version checking and .car file conversion will not be done which would be optimal to use
#                      when all environments are of the same major DV version such as all DV 7.x or all DV 8.x
# password is optional and must occur after the domain.  If not included, the user is prompted.
# encryptionPassword is optional and must occur after the server password.
#     It should only be supplied with version 8.x and higher.
#
# DISCLAIMER: 
#    Migrating resources from 8.x to 7.x is not generally supported.
#    However, it does provide a way to move basic functionality coded in 8.x to 7.x.  
#    It does not support the ability to move new features that exist in 8.x but do not exist in 7.x.  
#    Exceptions may be thrown in this circumstance.
#****************************************************************
#
######################################################################
#     Modified Date:	Modified By:        DV Version:		Reason:
#     10/16/2014		Jeremy Akers        6.2.6           Created new
#     05/30/2019		Mike Tinius			7.0.8			Modified to support conversion of .car files from DV 8.0 to DV 7.0.
#
# (c) 2017 TIBCO Software Inc. All rights reserved.
# 
# Except as specified below, this software is licensed pursuant to the Eclipse Public License v. 1.0.
# The details can be found in the file LICENSE.
# 
# The following proprietary files are included as a convenience, and may not be used except pursuant
# to valid license to Composite Information Server or TIBCO(R) Data Virtualization Server:
# csadmin-XXXX.jar, csarchive-XXXX.jar, csbase-XXXX.jar, csclient-XXXX.jar, cscommon-XXXX.jar,
# csext-XXXX.jar, csjdbc-XXXX.jar, csserverutil-XXXX.jar, csserver-XXXX.jar, cswebapi-XXXX.jar,
# and customproc-XXXX.jar (where -XXXX is an optional version number).  Any included third party files
# are licensed under the terms contained in their own accompanying LICENSE files, generally named .LICENSE.txt.
# 
# This software is licensed AS-IS. Support for this software is not covered by standard maintenance agreements with TIBCO.
# If you would like to obtain assistance with this software, such assistance may be obtained through a separate paid consulting
# agreement with TIBCO.
#
######################################################################
#****************************************************************
# FUNCTIONS
#****************************************************************

#----------------------------------------------------------------------------------
# Modify the variables below according to your environment.
#   DV_HOME, PRIVSFILE, RESOWNERFILE, FULLBACKUPPATH, WSPORT, DBPORT, DATABASE
#   DEBUG=Y will send the DEBUG value to TDV procedures and 
#         the procedures will write to DV cs_server.log file.
#        =N will do nothing.
#----------------------------------------------------------------------------------
get_DEBUG()         { echo "N"; }
get_DV_HOME()       { echo "/home/TDV7.0.8"; }
get_PRIVSFILE()     { echo "/home/deployment/privileges/privileges.xml"; }
get_RESOWNERFILE()  { echo "/home/deployment/privileges/resource_ownership.txt"; }
get_FULLBACKUPPATH(){ echo "/home/deployment/fullbackup"; }
get_WSPORT()        { echo "9400"; }
get_DBPORT()        { echo "9401"; }
get_DATABASE()      { echo "ASAssets"; }

#-------------------------------------------------------------
# Description: GetDVProcedureResults
# Verify the results from the output of a DV procedure call based on the search text.
# -- SEARCH_TEXT      v[in] - variable name containing the search text.
#                                    ex 1. search for a SUCCESS status returned
#                                          set SEARCH_TEXT=col\[1]=SUCCESS
#                                    ex 2. search for version 8 returned
#                                          set SEARCH_TEXT=col\[1]=8
# -- JDBC_RESULT_FILE v[in] - variable containing the full path to the JdbcSample script output.
# -- JDBC_RESULT_FILE2 [in] - variable containing the full path to the secondary temporary file.
# -- QUIET             [in] - variable containing the quiet value.
# -- DISPLAY_CONTENTS  [in] - variable containing true or false to display the contents of JDBC_RESULT_FILE.
# -- S                 [in] - variable containing this script name.
#
# -- RESULT           [out]   - variable name containing the result code which is set using exit /B %RESULT%
#                                     0=NOT FOUND, search text was not found
#                                     1=FOUND, search text found.
#                                    99=RESULT, file not found.
#-------------------------------------------------------------
GetDVProcedureResults() 
{
    SEARCH_TEXT="$1"
	JDBC_RESULT_FILE="$2"
	JDBC_RESULT_FILE2="$3"
	QUIET="$4"
	DISPLAY_CONTENTS="$5"
	S="$6"

	# Search the $JDBC_RESULT_FILE file for a result row from $SEARCH_TEXT.
	if [ -f "$JDBC_RESULT_FILE" ] ; then
		if [ "$QUIET" == "" ] ; then 
			echo "$S: *** sed 's/\`//g' \"$JDBC_RESULT_FILE\" > \"$JDBC_RESULT_FILE2\" ***"
			echo "$S: *** searchText=\`grep -e \"$SEARCH_TEXT\" \"$JDBC_RESULT_FILE2\"\` ***"
			echo "$S: *** File contents for JDBC_RESULT_FILE=\"$JDBC_RESULT_FILE\" ***"
			cat "$JDBC_RESULT_FILE"
		fi
		# Only display contents if DISPLAY_CONTENTS=true and QUIET=-q
		if [ "$QUIET" == "-q" ] && [ "$DISPLAY_CONTENTS" == "true" ] ; then 
			echo "$S: *** File contents for JDBC_RESULT_FILE=\"$JDBC_RESULT_FILE\" ***"
			cat "$JDBC_RESULT_FILE"
		fi
		# Perform the search for the SEARCH_TEXT in the JDBC_RESULT_FILE
		sed 's/`//g' "$JDBC_RESULT_FILE" > "$JDBC_RESULT_FILE2"
		searchText=`grep -e "$SEARCH_TEXT" "$JDBC_RESULT_FILE2"`
		if [ "$searchText" == "" ] ; then
			# Did not find search text
			RESULT="0"
		    echo "$S: *** Found=false  SEARCH_TEXT:$SEARCH_TEXT ***"
		else
			# Found search text becuase grep will return the row where the string was found.
			RESULT="1"
			echo "$S: *** Found=true  SEARCH_TEXT:$SEARCH_TEXT ***"
		fi
		# Clean up temporary files
		if [ -f "$JDBC_RESULT_FILE2" ] ; then rm -f "$JDBC_RESULT_FILE2" ; fi
	else
		# Clean up temporary files
		if [ -f "$JDBC_RESULT_FILE" ]  ; then rm -f "$JDBC_RESULT_FILE" ; fi
		if [ -f "$JDBC_RESULT_FILE2" ] ; then rm -f "$JDBC_RESULT_FILE2" ; fi
		echo "$S: *** Error.  File not found JDBC_RESULT_FILE=$JDBC_RESULT_FILE ***"
		RESULT="99";
	fi
	return $RESULT
}
#****************************************************************
# MAIN SCRIPT BODY
#****************************************************************
DEBUG=$(get_DEBUG)
DV_HOME=$(get_DV_HOME)
PRIVSFILE=$(get_PRIVSFILE)
RESOWNERFILE=$(get_RESOWNERFILE)
FULLBACKUPPATH=$(get_FULLBACKUPPATH)
WSPORT=$(get_WSPORT)
DBPORT=$(get_DBPORT)
DATABASE=$(get_DATABASE)

#----------------------------
# Set the script name
#----------------------------
S=$(basename -- "$0")

#----------------------------
# Assign input parameters
#----------------------------
CONVERT=
QUIET=-q
while [ "$1" == "-v" ] || [ "$1" == "-c" ] ; do
	if [ "$1" == "-v" ] ; then
		QUIET=
	fi
	if [ "$1" == "-c" ] ; then
		CONVERT="-c"
	fi
	shift
done
PKGFILE=$1
OPTFILE=$2
HOST=$3
USER=$4
DOMAIN=$5
PASSWORD=$6
ENCRYPTION_PASSWORD=$7

echo "=============================================================="
echo "$S: Begin Deployment"

#----------------------------
# Validate input parameters
#----------------------------
# Check for no input
if [ "$PKGFILE" == "" ] || [ "$OPTFILE" == "" ] || [ "$HOST" == "" ] || [ "$USER" == "" ] || [ "$DOMAIN" == "" ] ; then
   echo "===================================================================================================="
   echo "| One or more required input parameters are blank."
   echo "|"
   echo "| Usage: $S [-v] [-c] <CAR_file> <options_file> <hostname> <username> <domain> [password]"
   echo "|"
   echo "===================================================================================================="
   exit 1;
fi

# Ask for the password if it was not passed in
if [ "$PASSWORD" == "" ] ; then
    read -s -p "Password for $USER: " PASSWORD
fi

#----------------------------
# Resolve relative paths for the package file
#----------------------------
absolute=$PKGFILE
if [ -d "$PKGFILE" ]; then absolute=$absolute/.; fi
absolute=$(cd "$(dirname -- "$absolute")"; printf %s. "$PWD")
absolute="${absolute%?}"
FOLDER_NAME="$absolute/${f##*/}"
FILE_NAME="$(basename -- $PKGFILE)"
PKGFILE="${FOLDER_NAME}${FILE_NAME}"

#----------------------------
# Resolve relative paths for the option file
#----------------------------
absolute=$OPTFILE
if [ -d "$OPTFILE" ]; then absolute=$absolute/.; fi
absolute=$(cd "$(dirname -- "$absolute")"; printf %s. "$PWD")
absolute="${absolute%?}"
FOLDER_NAME="$absolute/${f##*/}"
FILE_NAME="$(basename -- $OPTFILE)"
OPTFILE="${FOLDER_NAME}${FILE_NAME}"

#----------------------------
# Resolve relative paths for the scriptdir
#----------------------------
SCRIPTDIR=`dirname path`
absolute=$SCRIPTDIR
if [ -d "$SCRIPTDIR" ]; then absolute=${absolute}/.; fi
absolute=$(cd "$(dirname -- "$absolute")"; printf %s. "$PWD")
absolute="${absolute%?}"
SCRIPTDIR="${absolute}"

#----------------------------
# Assign dynamic variables
#----------------------------
DT=`date +%Y_%m_%d`
TM=`date +%H_%M_%S`
MYDATETIME=${DT}_${TM}
BACKUPFILENAME=$FULLBACKUPPATH/pre_deploy_fsb_$MYDATETIME.car
JDBC_RESULT_FILE=$SCRIPTDIR/jdbcSampleResults.txt
JDBC_RESULT_FILE2=$SCRIPTDIR/jdbcSampleResults2.txt

# Determine whether to use the JdbcSample.sh in the local directory or DV_HOME/apps/jdbc directory.
JDBC_SAMPLE_EXEC=$DV_HOME/apps/jdbc/JdbcSample.sh
if [ -f "$SCRIPTDIR/JdbcSample.sh" ] ; then
	JDBC_SAMPLE_EXEC=$SCRIPTDIR/JdbcSample.sh
fi
if [ ! -f $JDBC_SAMPLE_EXEC ] ; then
   echo "$S Failure: The JdbcSample.sh script could not be found: $JDBC_SAMPLE_EXEC"
   exit 1
fi

# Setup the conversion scripts
if [ ! -f "$SCRIPTDIR/convertPkgFileV11_to_V10.sh" ] ; then
   echo "$S Failure: The package conversion script could not be found: $SCRIPTDIR/convertPkgFileV11_to_V10.sh"
   exit 1
fi
CONVERT_PKG_FILEV11="$SCRIPTDIR/convertPkgFileV11_to_V10.sh"

#----------------------------
# Display input
#----------------------------
echo "=============================================================="
echo "Parameters:"
echo "   DV_HOME=$DV_HOME"
echo "   DEBUG=$DEBUG"
echo "   QUIET=$QUIET"
echo "   CONVERT=$CONVERT"
echo "   PKGFILE=$PKGFILE"
echo "   OPTFILE=$OPTFILE"
echo "   DATABASE=$DATABASE"
echo "   HOST=$HOST"
echo "   WSPORT=$WSPORT"
echo "   DBPORT=$DBPORT"
echo "   USER=$USER"
echo "   DOMAIN=$DOMAIN"
echo "   SCRIPTDIR=$SCRIPTDIR"
echo "   PRIVSFILE=$PRIVSFILE"
echo "   RESOWNERFILE=$RESOWNERFILE"
echo "   BACKUPFILENAME=$BACKUPFILENAME"
echo "   JDBC_SAMPLE_EXEC=$JDBC_SAMPLE_EXEC"
echo "   CONVERT_PKG_FILEV11=$CONVERT_PKG_FILEV11"
echo

#----------------------------
# Validate files exist
#----------------------------
# Make sure the .car package file exists
if [ ! -f "$PKGFILE" ] ; then
   echo "===================================================================================================="
   echo "| The package .car file does not exist at path=$PKGFILE"
   echo "|"
   echo "| Usage: $S [-v] [-c] <CAR_file> <options_file> <hostname> <username> <domain> [password]"
   echo "|"
   echo "===================================================================================================="
   exit 1
fi

# Make sure the .car package file exists
if [ ! -f "$OPTFILE" ] ; then
   echo "===================================================================================================="
   echo "| The option file does not exist at path=$OPTFILE"
   echo "|"
   echo "| Usage: $S [-v] [-c] <CAR_file> <options_file> <hostname> <username> <domain> [password]"
   echo "|"
   echo "===================================================================================================="
   exit 1
fi

################################
# BEGIN CHECK SERVER VERSION
################################
	DV_PROCEDURE="getServerAttribute"
	echo "$S: --------------------------------------------------------------"
	echo "$S: *** Checking Server Version. ***"
	echo "$S: --------------------------------------------------------------"
	echo "$S: *** \"$JDBC_SAMPLE_EXEC\" \"$DATABASE\" \"$HOST\" \"$DBPORT\" \"$USER\" \"********\" \"$DOMAIN\" \"SELECT * FROM Utilities.repository.getServerAttribute('/server/config/info/version')\" > \"$JDBC_RESULT_FILE\" ***"
	"$JDBC_SAMPLE_EXEC" "$DATABASE" "$HOST" "$DBPORT" "$USER" "$PASSWORD" "$DOMAIN" "SELECT * FROM Utilities.repository.getServerAttribute('/server/config/info/version')" > "$JDBC_RESULT_FILE"
	ERROR=$?
	if [ $ERROR -ne 0 ] ; then
	   echo "$S: $DV_PROCEDURE failed.  Aborting script. Error code: $ERROR"
	   exit $ERROR;
	fi
	
	GetDVProcedureResults "col\[1]=8" "$JDBC_RESULT_FILE" "$JDBC_RESULT_FILE2" "$QUIET" "false" "$S"
	RESULT=$?
	if [ -f "$JDBC_RESULT_FILE" ]  ; then rm -f "$JDBC_RESULT_FILE" ; fi
	if [ $RESULT -gt 1 ] ; then 
		exit $RESULT;
	fi
	# Default so that version 8 was not found
	FOUND_DV_VERSION8="0"
	# Version 8 was found
	if [ $RESULT -eq 1 ] ; then 
		FOUND_DV_VERSION8="1"
	fi
	echo "$S: *** $DV_PROCEDURE successfully completed. ***"

	# If FOUND_DV_VERSION8=0, then this is probably a DV version 7 and conversion may be required.
	# If FOUND_DV_VERSION8=1, then this is a DV version 8 server so no package .car file conversion is required.
	if [ $FOUND_DV_VERSION8 -eq 0 ] ; then
		echo "$S: *** Version 8.x [false] FOUND_DV_VERSION8=$FOUND_DV_VERSION8 ***"
	else
		echo "$S: *** Version 8.x [true] FOUND_DV_VERSION8=$FOUND_DV_VERSION8 ***"
	fi
	echo
	
################################
# BEGIN CONVERT PACKAGE FILE
#       FROM VERSION 11 to 10
#       FOR MIGRATING 8.x to 7.x
################################
# Continue with conversion checking and .car file conversion when CONVERT == -c
if [ "$CONVERT" == "-c" ] ; then
	# Conversion is required for a package format version 11 being imported into a DV version 7.
	echo "$S: --------------------------------------------------------------"
	echo "$S: *** Converting Package File Version 11 to 10. ***"
	echo "$S: --------------------------------------------------------------"
	# If FOUND_DV_VERSION8=0, then this is probably a DV version 7 and conversion may be required.
	# If FOUND_DV_VERSION8=1, then this is a DV version 8 server so no package .car file conversion is required.
	if [ $FOUND_DV_VERSION8 -eq 0 ] ; then
		# Perform the conversion
		echo "$S: *** "$CONVERT_PKG_FILEV11" "$PKGFILE" $QUIET ***"
		"$CONVERT_PKG_FILEV11" "$PKGFILE" $QUIET
		IS_V11=$?
		if [ $IS_V11 -gt 1 ] ; then
		   echo "$S: Package conversion version failed.  Aborting script. Error code: $IS_V11"
		   exit $IS_V11;
		fi
		if [ $IS_V11 -eq 0 ] ; then echo "$S: *** No package .car file conversion required. ***" ; fi
		if [ $IS_V11 -eq 1 ] ; then echo "$S: *** Package .car file conversion successfully completed. ***" ; fi
	else
		echo "$S: *** No package .car file conversion required. ***"
	fi
	echo
fi

################################
# BEGIN FULL SERVER BACKUP
################################
echo "$S: --------------------------------------------------------------"
echo "$S: *** Backing up target server $HOST:$WSPORT ***"
echo "$S: --------------------------------------------------------------"
echo "$S: *** Backup file will be located at: $BACKUPFILENAME ***"
# Execute without the encryption password DV 7.x
if [ "$ENCRYPTION_PASSWORD" == "" ] ; then
   echo "$S: *** $DV_HOME/bin/backup_export.sh -pkgfile \"$BACKUPFILENAME\" -server \"$HOST\" -port \"$WSPORT\" -user \"$USER\" -password \"********\" -domain \"$DOMAIN\" -includeStatistics ***"
   "$DV_HOME/bin/backup_export.sh" -pkgfile "$BACKUPFILENAME" -server "$HOST" -port "$WSPORT" -user "$USER" -password "$PASSWORD" -domain "$DOMAIN" -includeStatistics
   ERROR=$?
# Execute with the encryption password DV 8.x
else
   echo "$S: *** $DV_HOME/bin/backup_export.sh -pkgfile $BACKUPFILENAME -server $HOST -port \"$WSPORT\" -user $USER -password \"********\" -domain $DOMAIN -includeStatistics -encryptionPassword \"********\" ***"
   "$DV_HOME/bin/backup_export.sh" -pkgfile "$BACKUPFILENAME" -server "$HOST" -port "$WSPORT" -user "$USER" -password "$PASSWORD" -domain "$DOMAIN" -includeStatistics -encryptionPassword "$ENCRYPTION_PASSWORD"
   ERROR=$?
fi
if [ $ERROR -ne 0 ] ; then
   echo "$S: backup_export failed.  Aborting script. Error code: $ERROR";
   exit $ERROR;
fi
echo "$S: *** Backup successfully created. ***"
echo

################################
# BEGIN CAR FILE IMPORT
################################
echo "$S: --------------------------------------------------------------"
echo "$S: *** Importing CAR file into target server $HOST:$WSPORT ***"
echo "$S: --------------------------------------------------------------"
echo "$S: *** $DV_HOME/bin/pkg_import.sh -pkgfile \"$PKGFILE\" -server \"$HOST\" -port \"$WSPORT\" -user \"$USER\" -domain \"$DOMAIN\" -password \"********\" -optfile \"$OPTFILE\" ***"
"$DV_HOME/bin/pkg_import.sh" -pkgfile "$PKGFILE" -server "$HOST" -port "$WSPORT" -user "$USER" -domain "$DOMAIN" -password "$PASSWORD" -optfile "$OPTFILE"
ERROR=$?
if [ $ERROR -ne 0 ] ; then
   echo "$S: pkg_import failed.  Aborting script. Error code: $ERROR";
   exit $ERROR;
fi
echo "$S: *** Package file successfully imported. ***"
echo

################################
# BEGIN IMPORT RESOURCE OWNERSHIP
################################
DV_PROCEDURE="importResourceOwnership"
echo "$S: --------------------------------------------------------------"
echo "$S: *** Resetting ownership of objects. ***"
echo "$S: --------------------------------------------------------------"
echo "$S: *** \"$JDBC_SAMPLE_EXEC\" \"$DATABASE\" \"$HOST\" \"$DBPORT\" \"$USER\" \"********\" \"$DOMAIN\" \"SELECT * FROM Utilities.deployment.importResourceOwnership('$DEBUG', '$RESOWNERFILE')\" > \"$JDBC_RESULT_FILE\" ***"
"$JDBC_SAMPLE_EXEC" "$DATABASE" "$HOST" "$DBPORT" "$USER" "$PASSWORD" "$DOMAIN" "SELECT * FROM Utilities.deployment.importResourceOwnership('$DEBUG', '$RESOWNERFILE')" > "$JDBC_RESULT_FILE"
ERROR=$?
if [ $ERROR -ne 0 ] ; then
   echo "$S: $DV_PROCEDURE failed.  Aborting script. Error code: $ERROR";
   exit $ERROR;
fi

# Check for SUCCESS result
GetDVProcedureResults "col\[1]=SUCCESS" "$JDBC_RESULT_FILE" "$JDBC_RESULT_FILE2" "$QUIET" "false" "$S"
RESULT=$?
if [ $RESULT -gt 1 ] ; then 
	exit $RESULT;
fi
if [ $RESULT -eq 0 ] ; then 
	# Check for WARNING result
	GetDVProcedureResults "col\[1]=WARNING" "$JDBC_RESULT_FILE" "$JDBC_RESULT_FILE2" "$QUIET" "true" "$S"
	RESULT=$?
	if [ $RESULT -gt 1 ] ; then 
		exit $RESULT;
	fi
	if [ $RESULT -eq 0 ] ; then 
		echo "$S: *** FAILURE: $DV_PROCEDURE did not return with a \"SUCCESS\" or \"WARNING\" status. ***"
		if [ -f "$JDBC_RESULT_FILE" ]  ; then rm -f "$JDBC_RESULT_FILE" ; fi
		exit 1;
	fi
fi
if [ -f "$JDBC_RESULT_FILE" ]  ; then rm -f "$JDBC_RESULT_FILE" ; fi
echo "$S: *** $DV_PROCEDURE successfully completed. ***"
echo

################################
# BEGIN RESOURCE PRIVILEGES
################################
DV_PROCEDURE="importResourcePrivileges"
echo "$S: --------------------------------------------------------------"
echo "$S: *** Resetting privileges on all objects. ***"
echo "$S: --------------------------------------------------------------"
echo "$S: *** \"$JDBC_SAMPLE_EXEC\" \"$DATABASE\" \"$HOST\" \"$DBPORT\" \"$USER\" \"********\" \"$DOMAIN\" \"SELECT * FROM Utilities.deployment.importResourcePrivileges('$DEBUG', 1, 0, 0, '$PRIVSFILE', 'SET_EXACTLY')\" > \"$JDBC_RESULT_FILE\" ***"
"$JDBC_SAMPLE_EXEC" "$DATABASE" "$HOST" "$DBPORT" "$USER" "$PASSWORD" "$DOMAIN" "SELECT * FROM Utilities.deployment.importResourcePrivileges('$DEBUG', 1, 0, 0, '$PRIVSFILE', 'SET_EXACTLY')" > "$JDBC_RESULT_FILE"
ERROR=$?
if [ $ERROR -ne 0 ] ; then
   echo "$S: $DV_PROCEDURE failed.  Aborting script. Error code: $ERROR";
   exit $ERROR;
fi

# Check for SUCCESS result
GetDVProcedureResults "col\[1]=SUCCESS" "$JDBC_RESULT_FILE" "$JDBC_RESULT_FILE2" "$QUIET" "false" "$S"
RESULT=$?
if [ $RESULT -gt 1 ] ; then 
	exit $RESULT;
fi
if [ $RESULT -eq 0 ] ; then 
	# Check for WARNING result
	GetDVProcedureResults "col\[1]=WARNING" "$JDBC_RESULT_FILE" "$JDBC_RESULT_FILE2" "$QUIET" "true" "$S"
	RESULT=$?
	if [ $RESULT -gt 1 ] ; then 
		exit $RESULT;
	fi
	if [ $RESULT -eq 0 ] ; then 
		echo "$S: *** FAILURE: $DV_PROCEDURE did not return with a \"SUCCESS\" or \"WARNING\" status. ***"
		if [ -f "$JDBC_RESULT_FILE" ]  ; then rm -f "$JDBC_RESULT_FILE" ; fi
		exit 1;
	fi
fi
if [ -f "$JDBC_RESULT_FILE" ]  ; then rm -f "$JDBC_RESULT_FILE" ; fi
echo "$S: *** $DV_PROCEDURE successfully completed. ***"
echo

################################
# BEGIN runAfterImport
################################
DV_PROCEDURE="runAfterImport"
echo "$S: --------------------------------------------------------------"
echo "$S: *** Calling runAfterImport for any post migration steps. ***"
echo "$S: --------------------------------------------------------------"
echo "$S: *** \"$JDBC_SAMPLE_EXEC\" \"$DATABASE\" \"$HOST\" \"$DBPORT\" \"$USER\" \"********\" \"$DOMAIN\" \"SELECT * FROM Utilities.deployment.runAfterImport('$DEBUG')\" > \"$JDBC_RESULT_FILE\" ***"
"$JDBC_SAMPLE_EXEC" "$DATABASE" "$HOST" "$DBPORT" "$USER" "$PASSWORD" "$DOMAIN" "SELECT * FROM Utilities.deployment.runAfterImport('$DEBUG')" > "$JDBC_RESULT_FILE"
ERROR=$?
if [ $ERROR -ne 0 ] ; then
   echo "$S: $DV_PROCEDURE failed.  Aborting script. Error code: $ERROR";
   exit $ERROR;
fi

# Check for SUCCESS result
GetDVProcedureResults "col\[1]=SUCCESS" "$JDBC_RESULT_FILE" "$JDBC_RESULT_FILE2" "$QUIET" "false" "$S"
RESULT=$?
if [ $RESULT -gt 1 ] ; then 
	exit $RESULT;
fi
if [ $RESULT -eq 0 ] ; then 
	# Check for WARNING result
	GetDVProcedureResults "col\[1]=WARNING" "$JDBC_RESULT_FILE" "$JDBC_RESULT_FILE2" "$QUIET" "true" "$S"
	RESULT=$?
	if [ $RESULT -gt 1 ] ; then 
		exit $RESULT;
	fi
	if [ $RESULT -eq 0 ] ; then 
		echo "$S: *** FAILURE: $DV_PROCEDURE did not return with a \"SUCCESS\" or \"WARNING\" status. ***"
		if [ -f "$JDBC_RESULT_FILE" ]  ; then rm -f "$JDBC_RESULT_FILE" ; fi
		exit 1;
	fi
fi
if [ -f "$JDBC_RESULT_FILE" ]  ; then rm -f "$JDBC_RESULT_FILE" ; fi
echo "$S: *** $DV_PROCEDURE successfully completed. ***"
echo

################################
# COMPLETE
################################
echo "$S: *** All migration steps successfully completed. ***"
echo "=============================================================="
exit 0
#****************************************************************
# END: deployProject.sh
#****************************************************************
