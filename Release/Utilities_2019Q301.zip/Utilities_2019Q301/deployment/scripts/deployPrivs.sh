#!/bin/bash
#****************************************************************
# BEGIN: deployPrivs.sh
#
# Usage: deployPrivs.sh [-v] <hostname> <username> <domain> [password]
# Any options [-v] must occur before any other parameters or this procedure will not work.
#  -v=[optional] verbose mode.  Verbose is turned on for secondary script calls.  Otherwise the default is verbose is off.
# password is optional.  If not included, the user is prompted.
#****************************************************************
#
######################################################################
#     Modified Date:	Modified By:        DV Version:		Reason:
#     10/16/2014		Jeremy Akers        6.2.6           Created new
#     05/30/2019		Mike Tinius			7.0.8			Modified to add debug/info.
#
# (c) 2017 TIBCO Software Inc. All rights reserved.
# 
# Except as specified below, this software is licensed pursuant to the Eclipse Public License v. 1.0.
# The details can be found in the file LICENSE.
# 
# The following proprietary files are included as a convenience, and may not be used except pursuant
# to valid license to Composite Information Server or TIBCO(R) Data Virtualization Server:
# csadmin-XXXX.jar, csarchive-XXXX.jar, csbase-XXXX.jar, csclient-XXXX.jar, cscommon-XXXX.jar,
# csext-XXXX.jar, csjdbc-XXXX.jar, csserverutil-XXXX.jar, csserver-XXXX.jar, cswebapi-XXXX.jar,
# and customproc-XXXX.jar (where -XXXX is an optional version number).  Any included third party files
# are licensed under the terms contained in their own accompanying LICENSE files, generally named .LICENSE.txt.
# 
# This software is licensed AS-IS. Support for this software is not covered by standard maintenance agreements with TIBCO.
# If you would like to obtain assistance with this software, such assistance may be obtained through a separate paid consulting
# agreement with TIBCO.
#
######################################################################
#
#****************************************************************
# FUNCTIONS
#****************************************************************

#----------------------------------------------------------------------------------
# Modify the variables below according to your environment.
#   DV_HOME, PRIVSFILE, RESOWNERFILE, DBPORT, DATABASE
#   DEBUG=Y will send the DEBUG value to TDV procedures and 
#         the procedures will write to DV cs_server.log file.
#        =N will do nothing.
#----------------------------------------------------------------------------------
get_DEBUG()         { echo "N"; }
get_DV_HOME()       { echo "/home/TDV7.0.8"; }
get_PRIVSFILE()     { echo "/home/deployment/privileges/privileges.xml"; }
get_RESOWNERFILE()  { echo "/home/deployment/privileges/resource_ownership.txt"; }
get_DBPORT()        { echo "9401"; }
get_DATABASE()      { echo "ASAssets"; }

#-------------------------------------------------------------
# Description: GetDVProcedureResults
# Verify the results from the output of a DV procedure call based on the search text.
# -- SEARCH_TEXT      v[in] - variable name containing the search text.
#                                    ex 1. search for a SUCCESS status returned
#                                          set SEARCH_TEXT=col\[1]=SUCCESS
#                                    ex 2. search for version 8 returned
#                                          set SEARCH_TEXT=col\[1]=8
# -- JDBC_RESULT_FILE v[in] - variable containing the full path to the JdbcSample script output.
# -- JDBC_RESULT_FILE2 [in] - variable containing the full path to the secondary temporary file.
# -- QUIET             [in] - variable containing the quiet value.
# -- DISPLAY_CONTENTS  [in] - variable containing true or false to display the contents of JDBC_RESULT_FILE.
# -- S                 [in] - variable containing this script name.
#
# -- RESULT           [out]   - variable name containing the result code which is set using exit /B %RESULT%
#                                     0=NOT FOUND, search text was not found
#                                     1=FOUND, search text found.
#                                    99=RESULT, file not found.
#-------------------------------------------------------------
GetDVProcedureResults() 
{
    SEARCH_TEXT="$1"
	JDBC_RESULT_FILE="$2"
	JDBC_RESULT_FILE2="$3"
	QUIET="$4"
	DISPLAY_CONTENTS="$5"
	S="$6"

	# Search the $JDBC_RESULT_FILE file for a result row from $SEARCH_TEXT.
	if [ -f "$JDBC_RESULT_FILE" ] ; then
		if [ "$QUIET" == "" ] ; then 
			echo "$S: *** sed 's/\`//g' \"$JDBC_RESULT_FILE\" > \"$JDBC_RESULT_FILE2\" ***"
			echo "$S: *** searchText=\`grep -e \"$SEARCH_TEXT\" \"$JDBC_RESULT_FILE2\"\` ***"
			echo "$S: *** File contents for JDBC_RESULT_FILE=\"$JDBC_RESULT_FILE\" ***"
			cat "$JDBC_RESULT_FILE"
		fi
		# Only display contents if DISPLAY_CONTENTS=true and QUIET=-q
		if [ "$QUIET" == "-q" ] && [ "$DISPLAY_CONTENTS" == "true" ] ; then 
			echo "$S: *** File contents for JDBC_RESULT_FILE=\"$JDBC_RESULT_FILE\" ***"
			cat "$JDBC_RESULT_FILE"
		fi
		# Perform the search for the SEARCH_TEXT in the JDBC_RESULT_FILE
		sed 's/`//g' "$JDBC_RESULT_FILE" > "$JDBC_RESULT_FILE2"
		searchText=`grep -e "$SEARCH_TEXT" "$JDBC_RESULT_FILE2"`
		if [ "$searchText" == "" ] ; then
			# Did not find search text
			RESULT="0"
		    echo "$S: *** Found=false  SEARCH_TEXT:$SEARCH_TEXT ***"
		else
			# Found search text becuase grep will return the row where the string was found.
			RESULT="1"
			echo "$S: *** Found=true  SEARCH_TEXT:$SEARCH_TEXT ***"
		fi
		# Clean up temporary files
		if [ -f "$JDBC_RESULT_FILE2" ] ; then rm -f "$JDBC_RESULT_FILE2" ; fi
	else
		# Clean up temporary files
		if [ -f "$JDBC_RESULT_FILE" ]  ; then rm -f "$JDBC_RESULT_FILE" ; fi
		if [ -f "$JDBC_RESULT_FILE2" ] ; then rm -f "$JDBC_RESULT_FILE2" ; fi
		echo "$S: *** Error.  File not found JDBC_RESULT_FILE=$JDBC_RESULT_FILE ***"
		RESULT="99";
	fi
	return $RESULT
}
#****************************************************************
# MAIN SCRIPT BODY
#****************************************************************
DEBUG=$(get_DEBUG)
DV_HOME=$(get_DV_HOME)
PRIVSFILE=$(get_PRIVSFILE)
RESOWNERFILE=$(get_RESOWNERFILE)
DBPORT=$(get_DBPORT)
DATABASE=$(get_DATABASE)

#----------------------------
# Set the script name
#----------------------------
S=$(basename -- "$0")

#----------------------------
# Assign input parameters
#----------------------------
QUIET=-q
while [ "$1" == "-v" ] ; do
	QUIET=
	shift
done
HOST=$1
USER=$2
DOMAIN=$3
PASSWORD=$4

echo "=============================================================="
echo "$S: Begin Deploy Privileges"

#----------------------------
# Validate input parameters
#----------------------------
if [ "$HOST" == "" ] || [ "$USER" == "" ] || [ "$DOMAIN" == "" ] ; then
   echo "===================================================================================================="
   echo "| One or more required input parameters are blank."
   echo "|"
   echo "| Usage: $S [-v] <hostname> <username> <domain> [password]"
   echo "|"
   echo "===================================================================================================="
   exit 1;
fi

# Ask for the password if it was not passed in
if [ "$PASSWORD" == "" ] ; then
   read -s -p "Password for $USER: " PASSWORD
fi

#----------------------------
# Resolve relative paths for the scriptdir
#----------------------------
SCRIPTDIR=`dirname path`
absolute=$SCRIPTDIR
if [ -d "$SCRIPTDIR" ]; then absolute=${absolute}/.; fi
absolute=$(cd "$(dirname -- "$absolute")"; printf %s. "$PWD")
absolute="${absolute%?}"
SCRIPTDIR="${absolute}"
JDBC_RESULT_FILE=$SCRIPTDIR/jdbcSampleResults.txt
JDBC_RESULT_FILE2=$SCRIPTDIR/jdbcSampleResults2.txt

#----------------------------
# Assign dynamic variables
#----------------------------
# Determine whether to use the JdbcSample.sh in the local directory or DV_HOME/apps/jdbc directory.
JDBC_SAMPLE_EXEC=$DV_HOME/apps/jdbc/JdbcSample.sh
if [ -f "$SCRIPTDIR/JdbcSample.sh" ] ; then
	JDBC_SAMPLE_EXEC=$SCRIPTDIR/JdbcSample.sh
fi
if [ ! -f $JDBC_SAMPLE_EXEC ] ; then
   echo "$S Failure: The JdbcSample.sh script could not be found: $JDBC_SAMPLE_EXEC"
   exit 1
fi

#----------------------------
# Display input
#----------------------------
echo "=============================================================="
echo "Parameters:"
echo "   DV_HOME=$DV_HOME"
echo "   DEBUG=$DEBUG"
echo "   DATABASE=$DATABASE"
echo "   HOST=$HOST"
echo "   DBPORT=$DBPORT"
echo "   USER=$USER"
echo "   DOMAIN=$DOMAIN"
echo "   SCRIPTDIR=$SCRIPTDIR"
echo "   PRIVSFILE=$PRIVSFILE"
echo "   RESOWNERFILE=$RESOWNERFILE"
echo "   JDBC_SAMPLE_EXEC=$JDBC_SAMPLE_EXEC"
echo

################################
# BEGIN IMPORT RESOURCE OWNERSHIP
################################
DV_PROCEDURE="importResourceOwnership"
echo "$S: --------------------------------------------------------------"
echo "$S: *** Resetting ownership of objects. ***"
echo "$S: --------------------------------------------------------------"
echo "$S: *** \"$JDBC_SAMPLE_EXEC\" \"$DATABASE\" \"$HOST\" \"$DBPORT\" \"$USER\" \"********\" \"$DOMAIN\" \"SELECT * FROM Utilities.deployment.importResourceOwnership('$DEBUG', '$RESOWNERFILE')\" > \"$JDBC_RESULT_FILE\" ***"
"$JDBC_SAMPLE_EXEC" "$DATABASE" "$HOST" "$DBPORT" "$USER" "$PASSWORD" "$DOMAIN" "SELECT * FROM Utilities.deployment.importResourceOwnership('$DEBUG', '$RESOWNERFILE')" > "$JDBC_RESULT_FILE"
ERROR=$?
if [ $ERROR -ne 0 ] ; then
   echo "$S: $DV_PROCEDURE failed.  Aborting script. Error code: $ERROR";
   exit $ERROR;
fi

# Check for SUCCESS result
GetDVProcedureResults "col\[1]=SUCCESS" "$JDBC_RESULT_FILE" "$JDBC_RESULT_FILE2" "$QUIET" "false" "$S"
RESULT=$?
if [ $RESULT -gt 1 ] ; then 
	exit $RESULT;
fi
if [ $RESULT -eq 0 ] ; then 
	# Check for WARNING result
	GetDVProcedureResults "col\[1]=WARNING" "$JDBC_RESULT_FILE" "$JDBC_RESULT_FILE2" "$QUIET" "true" "$S"
	RESULT=$?
	if [ $RESULT -gt 1 ] ; then 
		exit $RESULT;
	fi
	if [ $RESULT -eq 0 ] ; then 
		echo "$S: *** FAILURE: $DV_PROCEDURE did not return with a \"SUCCESS\" or \"WARNING\" status. ***"
		if [ -f "$JDBC_RESULT_FILE" ]  ; then rm -f "$JDBC_RESULT_FILE" ; fi
		exit 99;
	fi
fi
if [ -f "$JDBC_RESULT_FILE" ]  ; then rm -f "$JDBC_RESULT_FILE" ; fi
echo "$S: *** $DV_PROCEDURE successfully completed. ***"
echo

################################
# BEGIN RESOURCE PRIVILEGES
################################
DV_PROCEDURE="importResourcePrivileges"
echo "$S: --------------------------------------------------------------"
echo "$S: *** Resetting privileges on all objects. ***"
echo "$S: --------------------------------------------------------------"
echo "$S: *** \"$JDBC_SAMPLE_EXEC\" \"$DATABASE\" \"$HOST\" \"$DBPORT\" \"$USER\" \"********\" \"$DOMAIN\" \"SELECT * FROM Utilities.deployment.importResourcePrivileges('$DEBUG', 1, 0, 0, '$PRIVSFILE', 'SET_EXACTLY')\" > \"$JDBC_RESULT_FILE\" ***"
"$JDBC_SAMPLE_EXEC" "$DATABASE" "$HOST" "$DBPORT" "$USER" "$PASSWORD" "$DOMAIN" "SELECT * FROM Utilities.deployment.importResourcePrivileges('$DEBUG', 1, 0, 0, '$PRIVSFILE', 'SET_EXACTLY')" > "$JDBC_RESULT_FILE"
ERROR=$?
if [ $ERROR -ne 0 ] ; then
   echo "$S: $DV_PROCEDURE failed.  Aborting script. Error code: $ERROR";
   exit $ERROR;
fi

# Check for SUCCESS result
GetDVProcedureResults "col\[1]=SUCCESS" "$JDBC_RESULT_FILE" "$JDBC_RESULT_FILE2" "$QUIET" "false" "$S"
RESULT=$?
if [ $RESULT -gt 1 ] ; then 
	exit $RESULT;
fi
if [ $RESULT -eq 0 ] ; then 
	# Check for WARNING result
	GetDVProcedureResults "col\[1]=WARNING" "$JDBC_RESULT_FILE" "$JDBC_RESULT_FILE2" "$QUIET" "true" "$S"
	RESULT=$?
	if [ $RESULT -gt 1 ] ; then 
		exit $RESULT;
	fi
	if [ $RESULT -eq 0 ] ; then 
		echo "$S: *** FAILURE: $DV_PROCEDURE did not return with a \"SUCCESS\" or \"WARNING\" status. ***"
		if [ -f "$JDBC_RESULT_FILE" ]  ; then rm -f "$JDBC_RESULT_FILE" ; fi
		exit 99;
	fi
fi
if [ -f "$JDBC_RESULT_FILE" ]  ; then rm -f "$JDBC_RESULT_FILE" ; fi
echo "$S: *** $DV_PROCEDURE successfully completed. ***"
echo

################################
# COMPLETE
################################
echo "$S: *** All privilege steps successfully completed. ***"
echo "=============================================================="
exit 0;
#****************************************************************
# END: deployPrivs.sh
#****************************************************************